#!/usr/bin/env python3
"""Experiment 049: reproducible synthetic witness/checkpoint falsification harness.

Run: python -m pip install 'cryptography>=42'
     python reik_checkpoint_049.py --json

Synthetic deterministic keys are publicly predictable DEMO ONLY. They are never
legitimate witnesses or signatures on a real-world REIK ledger. This program
never makes network calls, accepts credentials, or modifies external state.
"""
import argparse
import hashlib
import json
from dataclasses import dataclass
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

CP_DOMAIN = b"REIK-TCGE-049/checkpoint/v1\x00"
ROT_DOMAIN = b"REIK-TCGE-049/rotation/v1\x00"
POLICY = "three-of-four-non-equivocating-assumed"
GENESIS = hashlib.sha256(b"Experiment049-SYNTHETIC-GENESIS").hexdigest()
LEDGER = "demo-ledger-049-NOT-REAL"


def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode("ascii")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(data):
    return sha(canonical(data))


def key(name):
    # Publicly reconstructible deterministic test-only private key; no secrets.
    return Ed25519PrivateKey.from_private_bytes(hashlib.sha256(("synthetic-049/" + name).encode()).digest())


def roster(names):
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    return {n: key(n).public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex() for n in names}


def checkpoint(epoch, height, tip, parent, roster_digest, policy=POLICY):
    return {"kind": "checkpoint", "protocol": "REIK/TCGE/049-demo", "ledger": LEDGER,
            "genesis": GENESIS, "epoch": epoch, "height": height,
            "tip": tip, "parent": parent, "roster_digest": roster_digest, "policy": policy}


def sign(payload, who, domain=CP_DOMAIN):
    return {"who": who, "sig": key(who).sign(domain + canonical(payload)).hex()}


def crypto_verify(payload, signatures, known_roster, domain):
    if type(signatures) is not list:
        raise ValueError("signatures must be a list")
    seen, seen_keys = set(), set()
    if len(set(known_roster.values())) != len(known_roster):
        raise ValueError("duplicate public-key identities in roster")
    for entry in signatures:
        if type(entry) is not dict or set(entry) != {"who", "sig"}:
            raise ValueError("malformed signature entry")
        who = entry["who"]
        if who in seen or who not in known_roster:
            raise ValueError("duplicate or unrecognized signer")
        seen.add(who)
        if known_roster[who] in seen_keys:
            raise ValueError("duplicate public key")
        seen_keys.add(known_roster[who])
        try:
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(known_roster[who])).verify(
                bytes.fromhex(entry["sig"]), domain + canonical(payload))
        except (InvalidSignature, ValueError, TypeError) as exc:
            raise ValueError("invalid signature") from exc
    return len(seen)


@dataclass(frozen=True)
class Trust:
    roster_digest: str  # must be obtained out-of-band from independent trust origin
    policy: str
    genesis: str
    ledger: str
    epoch: int


def verify_cert(cp, signatures, known_roster, trust, anchor, q=3):
    """Verify *one next-link* relative to a separately pinned trust & anchor.

    This deliberately does NOT establish provenance of pins, signer independence,
    global dissemination or correct scientific content. Inputs must be trusted
    from outside the certificate itself; never load trust from an envelope.
    """
    if set(cp) != {"kind", "protocol", "ledger", "genesis", "epoch", "height",
                   "tip", "parent", "roster_digest", "policy"}:
        raise ValueError("malformed checkpoint")
    if cp["kind"] != "checkpoint" or cp["protocol"] != "REIK/TCGE/049-demo":
        raise ValueError("protocol mismatch")
    if cp["ledger"] != trust.ledger or cp["genesis"] != trust.genesis:
        raise ValueError("ledger/genesis mismatch")
    if cp["epoch"] != trust.epoch:
        raise ValueError("checkpoint epoch is not trusted")
    if cp["policy"] != trust.policy or cp["roster_digest"] != trust.roster_digest:
        raise ValueError("policy or roster mismatch with independent trust")
    if digest(known_roster) != trust.roster_digest:
        raise ValueError("witness roster is not pinned")
    if type(cp["height"]) is not int or type(cp["epoch"]) is not int or cp["epoch"] < 1:
        raise ValueError("invalid height or epoch")
    if cp["height"] != anchor["height"] + 1 or cp["parent"] != anchor["digest"]:
        raise ValueError("rollback, fork, missing intermediate link or wrong anchor")
    if q != 3 or len(known_roster) != 4:
        raise ValueError("unapproved threshold policy")
    if crypto_verify(cp, signatures, known_roster, CP_DOMAIN) < q:
        raise ValueError("insufficient quorum")
    return digest(cp)


def rotation(new_epoch, new_roster, parent, prior_roster_digest):
    return {"kind": "rotation", "protocol": "REIK/TCGE/049-demo", "ledger": LEDGER,
            "genesis": GENESIS, "new_epoch": new_epoch, "parent": parent,
            "prior_roster_digest": prior_roster_digest,
            "new_roster_digest": digest(new_roster), "policy": POLICY}


def verify_rotation(record, sigs, prior_roster, prior_trust, anchor, new_roster):
    if set(record) != {"kind", "protocol", "ledger", "genesis", "new_epoch", "parent",
                       "prior_roster_digest", "new_roster_digest", "policy"}:
        raise ValueError("malformed rotation")
    if record["kind"] != "rotation" or record["protocol"] != "REIK/TCGE/049-demo":
        raise ValueError("wrong rotation domain")
    if record["ledger"] != prior_trust.ledger or record["genesis"] != prior_trust.genesis:
        raise ValueError("rotation ledger/genesis mismatch")
    if record["new_epoch"] != anchor["epoch"] + 1:
        raise ValueError("rotation epoch gap/replay")
    if record["parent"] != anchor["digest"]:
        raise ValueError("rotation parent missing/altered")
    if record["prior_roster_digest"] != prior_trust.roster_digest:
        raise ValueError("unknown prior roster")
    if digest(prior_roster) != prior_trust.roster_digest or record["policy"] != prior_trust.policy:
        raise ValueError("untrusted prior roster or policy")
    if record["new_roster_digest"] != digest(new_roster):
        raise ValueError("new roster digest differs from authorization")
    if crypto_verify(record, sigs, prior_roster, ROT_DOMAIN) < 3:
        raise ValueError("insufficient old-roster consent")
    return Trust(digest(new_roster), POLICY, prior_trust.genesis, prior_trust.ledger, record["new_epoch"])


class Harness:
    def __init__(self):
        self.results = []
    def ok(self, name, condition):
        self.results.append({"test": name, "pass": bool(condition)})
        if not condition:
            raise AssertionError(name)
    def rejects(self, name, call):
        try:
            call()
        except (ValueError, InvalidSignature):
            self.ok(name, True)
        else:
            self.ok(name, False)


def run():
    h = Harness()
    r1 = roster(["A", "B", "C", "D"])
    t1 = Trust(digest(r1), POLICY, GENESIS, LEDGER, 1)
    root = {"height": 0, "epoch": 1, "digest": sha(b"synthetic-049-root")}
    cp1 = checkpoint(1, 1, sha(b"event-one"), root["digest"], digest(r1))
    s1 = [sign(cp1, n) for n in ("A", "B", "C")]
    d1 = digest(cp1)
    h.ok("pinned three-of-four checkpoint accepted", verify_cert(cp1, s1, r1, t1, root) == d1)
    h.ok("quorum arithmetic strong intersect=2", 2 * 3 - 4 == 2)
    h.ok("quorum arithmetic weak intersect=0", max(0, 2 * 2 - 4) == 0)
    h.rejects("two signatures not authorized", lambda: verify_cert(cp1, s1[:2], r1, t1, root))
    h.rejects("duplicate signer not counted twice", lambda: verify_cert(cp1, [s1[0], s1[0], s1[1]], r1, t1, root))
    h.rejects("unknown signer rejected", lambda: verify_cert(cp1, s1[:2] + [sign(cp1, "X")], r1, t1, root))
    h.rejects("tampered signature rejected", lambda: verify_cert(cp1, [dict(s1[0], sig="00"*64)] + s1[1:], r1, t1, root))
    h.rejects("malformed certificate rejected", lambda: verify_cert(cp1, [dict(s1[0], extra=1)] + s1[1:], r1, t1, root))
    h.rejects("edited tip rejected", lambda: verify_cert(dict(cp1, tip=sha(b"other")), s1, r1, t1, root))
    h.rejects("edited checkpoint policy rejected", lambda: verify_cert(dict(cp1, policy="q2"), s1, r1, t1, root))
    h.rejects("edited genesis rejected", lambda: verify_cert(dict(cp1, genesis="ff"*32), s1, r1, t1, root))
    h.rejects("wrong ledger rejected", lambda: verify_cert(dict(cp1, ledger="attacker-ledger"), s1, r1, t1, root))
    h.rejects("wrong epoch signature rejected", lambda: verify_cert(dict(cp1, epoch=2), s1, r1, t1, root))
    h.rejects("even correctly re-signed untrusted epoch rejected", lambda: verify_cert(dict(cp1, epoch=3), [sign(dict(cp1, epoch=3),n) for n in ("A","B","C")], r1, t1, root))
    h.rejects("wrong parent rejected", lambda: verify_cert(dict(cp1, parent="ff"*32), s1, r1, t1, root))
    h.rejects("skipped height rejected", lambda: verify_cert(dict(cp1, height=3), s1, r1, t1, root))
    h.rejects("missing trusted anchor rejected", lambda: verify_cert(cp1, s1, r1, t1, {"height": 0, "digest": "00"*32}))
    h.rejects("downgraded verifier threshold rejected", lambda: verify_cert(cp1, s1, r1, t1, root, q=2))
    h.rejects("wrong roster rejected", lambda: verify_cert(cp1, s1, roster(["W", "X", "Y", "Z"]), t1, root))
    h.rejects("duplicate underlying pubkeys rejected", lambda: verify_cert(cp1, s1, {"A":r1["A"],"B":r1["A"],"C":r1["C"],"D":r1["D"]}, t1, root))
    h.rejects("cross-domain signatures rejected", lambda: verify_cert(cp1, [sign(cp1,n,ROT_DOMAIN) for n in ("A","B","C")], r1, t1, root))
    # An attacker can fabricate an entire internally consistent unpinned roster.
    fake_roster = roster(["W", "X", "Y", "Z"])
    fake = checkpoint(1, 1, sha(b"fake"), root["digest"], digest(fake_roster))
    fake_sigs = [sign(fake,n) for n in ("W","X","Y")]
    h.ok("untrusted self-consistent alternative roster signs cryptographically", crypto_verify(fake,fake_sigs,fake_roster,CP_DOMAIN) == 3)
    h.rejects("alternative roster rejected by independent pinned trust", lambda: verify_cert(fake, fake_sigs, fake_roster, t1, root))
    # Two incompatible checkpoints can BOTH carry authentic signatures even under q3.
    fork = checkpoint(1, 1, sha(b"conflicting-event"), root["digest"], digest(r1))
    fork_sigs = [sign(fork, n) for n in ("A", "B", "D")]
    h.ok("first conflicting 3-of-4 certificate cryptographically valid", crypto_verify(cp1,s1,r1,CP_DOMAIN)==3)
    h.ok("second conflicting 3-of-4 certificate cryptographically valid", crypto_verify(fork,fork_sigs,r1,CP_DOMAIN)==3)
    h.ok("same-height conflict detectable if both reports visible", cp1["ledger"]==fork["ledger"] and cp1["epoch"]==fork["epoch"] and cp1["height"]==fork["height"] and digest(cp1)!=digest(fork))
    # Honest witness storage vetoes a signer that already signed for that tuple.
    signed = {(name, cp1["ledger"],cp1["epoch"],cp1["height"]): d1 for name in ("A","B","C")}
    h.ok("honest non-equivocation vetoes overlapping A", signed[("A",LEDGER,1,1)] != digest(fork))
    h.ok("honest non-equivocation vetoes overlapping B", signed[("B",LEDGER,1,1)] != digest(fork))
    h.ok("conflicting certificate impossible with f<=1 only under non-equivocation", len(set(("A","B","C")) & set(("A","B","D")))>1)
    # Weak quorums can be disjoint with no double-signing.
    h.ok("disjoint weak quorum AB and CD", set(("A","B")).isdisjoint(("C","D")))
    h.ok("weak first certificate verifies mathematically", crypto_verify(cp1,[sign(cp1,n) for n in ("A","B")],r1,CP_DOMAIN)==2)
    h.ok("weak conflicting certificate verifies mathematically", crypto_verify(fork,[sign(fork,n) for n in ("C","D")],r1,CP_DOMAIN)==2)
    h.rejects("trusted checkpoint fork flagged", lambda: verify_cert(fork,fork_sigs,r1,t1,{"height":1,"digest":d1}))
    h.rejects("trusted checkpoint rollback flagged", lambda: verify_cert(cp1,s1,r1,t1,{"height":2,"digest":sha(b"later")}))
    # Next append-only link and old-roster-authorized epoch rotation.
    cp2 = checkpoint(1, 2, sha(b"event-two"), d1, digest(r1))
    s2 = [sign(cp2,n) for n in ("A","C","D")]
    d2 = verify_cert(cp2, s2, r1, t1, {"height":1,"epoch":1,"digest":d1})
    h.ok("next checkpoint chain link accepted", d2==digest(cp2))
    r2 = roster(["E", "F", "G", "H"])
    rot = rotation(2,r2,d2,digest(r1))
    rs = [sign(rot,n,ROT_DOMAIN) for n in ("A","B","D")]
    anchor2 = {"height":2,"epoch":1,"digest":d2}
    t2 = verify_rotation(rot,rs,r1,t1,anchor2,r2)
    h.ok("old roster authorized new pinned roster",t2.roster_digest==digest(r2))
    h.rejects("rotation without old-roster quorum", lambda: verify_rotation(rot,rs[:2],r1,t1,anchor2,r2))
    h.rejects("rotation with changed new roster", lambda: verify_rotation(rot,rs,r1,t1,anchor2,fake_roster))
    h.rejects("rotation without pinned prior anchor", lambda: verify_rotation(rot,rs,r1,t1,{"height":2,"epoch":1,"digest":"ff"*32},r2))
    h.rejects("rotation epoch replay",lambda: verify_rotation(dict(rot,new_epoch=1),rs,r1,t1,anchor2,r2))
    h.rejects("rotation signed under checkpoint domain",lambda:verify_rotation(rot,[sign(rot,n,CP_DOMAIN) for n in ("A","B","D")],r1,t1,anchor2,r2))
    cp3 = checkpoint(2,3,sha(b"event-three"),d2,digest(r2))
    s3 = [sign(cp3,n) for n in ("E","F","H")]
    h.ok("rotated epoch checkpoint accepted",verify_cert(cp3,s3,r2,t2,anchor2)==digest(cp3))
    h.rejects("cross-epoch prior-roster signatures rejected",lambda:verify_cert(cp3,[sign(cp3,n) for n in ("A","B","C")],r2,t2,anchor2))
    h.rejects("new roster not trusted before rotation",lambda:verify_cert(cp3,s3,r2,t1,anchor2))
    # Signature authenticity is NOT knowledge, independence, science, or dissemination.
    h.ok("signatures check bytes not scientific validity",crypto_verify(cp1,s1,r1,CP_DOMAIN)==3)
    h.ok("demo roster contains only declared synthetic witness labels",set(r1)=={"A","B","C","D"})
    total=len(h.results)
    return {"experiment":"049", "scope":"synthetic deterministic public test fixtures only",
            "status":"0 HOLD; DROP U", "tests":total, "passed":sum(r["pass"] for r in h.results),
            "failures":[r["test"] for r in h.results if not r["pass"]],
            "fixtures":{"genesis_sha256":GENESIS,"roster1_sha256":digest(r1),"roster2_sha256":digest(r2),
                        "checkpoint1_sha256":d1,"checkpoint2_sha256":d2,
                        "rotation_sha256":digest(rot),"checkpoint3_sha256":digest(cp3),
                        "conflicting_checkpoint_sha256":digest(fork)},
            "limits":["No external witness/authenticated organization", "No real network gossip or trust origin",
                      "No real secret keys; publicly deterministic fixtures", "No proof of scientific truth or P vs NP",
                      "No original Experiment 048 verifier replay", "Uses same Python cryptography dependency"],
            "checks":h.results}


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--json",action="store_true")
    opts=p.parse_args()
    out=run()
    if opts.json:
        print(json.dumps(out,sort_keys=True,indent=2))
    else:
        print(f"REIK 049 {out['passed']}/{out['tests']} PASS; state {out['status']}")
    raise SystemExit(0 if out["passed"]==out["tests"] else 1)
